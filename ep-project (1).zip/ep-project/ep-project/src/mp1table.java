
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/mp1table")
public class mp1table extends HttpServlet {
  public void service(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
  {
    try {
      Connection con=null;
      Class.forName("com.mysql.jdbc.Driver");
      System.out.println("Driver Class Loaded");
      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ep_project","root","root");
      
    res.setContentType("text/html");
    PrintWriter out=res.getWriter();
    String title=req.getParameter("title");
    String number=req.getParameter("ticket-type");
    String marks=req.getParameter("marks");
    String date=req.getParameter("date");
    
    String qry="insert into csetable values('"+title+"','"+number+"','"+marks+"','"+date+"')";
    Statement smt=con.createStatement();
    int n=smt.executeUpdate(qry);
    if(n==1)
    {
    	res.sendRedirect("Skill_Project/mp1paper.jsp"); 
    }
    else 
    {
      out.println("Registration failed");
    }
    }
    catch (Exception e) {
      System.out.println(e);
    }
  }
}
