
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/adminmp1")
public class adminmp1 extends HttpServlet {
  public void service(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
  {
    try {
      Connection con=null;
      Class.forName("com.mysql.jdbc.Driver");
      System.out.println("Driver Class Loaded");
      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ep_project","root","root");
      
    res.setContentType("text/html");
    PrintWriter out=res.getWriter();
    String name=req.getParameter("question");
    int id=(int)(Math.random() * 99999)+9999;
    
    String qry="insert into mp2table values('"+id+"','"+name+"')";
    Statement smt=con.createStatement();
    int n=smt.executeUpdate(qry);
    if(n==1)
    {
    	res.sendRedirect("Skill_Project/adminhome.jsp"); 
    }
    else 
    {
      out.println("Registration failed");
    }
    }
    catch (Exception e) {
      System.out.println(e);
    }
  }
}
