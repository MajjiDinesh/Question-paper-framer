import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginadmin")
public class loginadmin extends HttpServlet {
  public void service(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
  {
    res.setContentType("text/html");
    PrintWriter out=res.getWriter();
    try {
       Connection con=null;
       Class.forName("com.mysql.jdbc.Driver");
      System.out.println("Driver Class Loaded");
      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ep_project","root","root");
      System.out.println("Connection Established");
          System.out.println("Welcome to servlets login Page");
        
    String email=req.getParameter("email");
    String pass=req.getParameter("pass");
    String ID=req.getParameter("ID");
    String qry="select * from registration where email='"+email+"'";
    Statement smt=con.createStatement();
    ResultSet rs=smt.executeQuery(qry);

    if(rs.next())
    {
      HttpSession session=req.getSession();
      session.setAttribute("email", rs.getString("email"));
      session.setAttribute("ID", rs.getString("ID"));
     
      out.println("Login was successful!!");

      res.sendRedirect("Skill_Project/adminhome.jsp"); 
    }
    else 
    {
      out.println("Login invalid");
    }
   }
    catch (Exception e) {
      System.out.println(e);
    }
  }
}